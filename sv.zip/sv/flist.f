sv/riscv_pkg.sv
sv/alu.sv
sv/fetch.sv
sv/decoder.sv
sv/regfile.sv
sv/memory.sv
sv/core.sv
sv/tb/riscv_tb.sv
